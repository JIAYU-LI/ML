"""Collection of utils for plotting various regraph objects."""
import copy

import networkx as nx
import numpy as np

from utils import keys_by_value
from matplotlib import pyplot as plt
from PIL import Image
import math
from random import random


def _ticks_off():
    plt.tick_params(
        axis='x',           # changes apply to the x-axis
        which='both',       # both major and minor ticks are affected
        bottom='off',       # ticks along the bottom edge are off
        top='off',          # ticks along the top edge are off
        labelbottom='off')  # labels along the bottom edge are off
    plt.tick_params(
        axis='y',           # changes apply to the x-axis
        which='both',       # both major and minor ticks are affected
        left='off',         # ticks along the bottom edge are off
        right='off',        # ticks along the top edge are off
        labelleft='off')    # labels along the bottom edge are off


def _set_limits(nodes, labels, margin=0.1):
    xmin = min([
        p[0] for _, p in nodes.items()
    ])
    xmax = max([
        p[0] for _, p in nodes.items()
    ])
    ymin = min([
        p[1] for _, p in nodes.items()
    ])
    ymax = max([
        p[1] for _, p in labels.items()
    ])

    plt.xlim([
        xmin - margin * abs(xmax - xmin),
        xmax + margin * abs(xmax - xmin)
    ])
    plt.ylim([
        ymin - margin * abs(ymax - ymin),
        ymax + margin * abs(ymax - ymin)
    ])
    return


def plot_graph(graph,filename=None, title=None):
    """Plot networkx graph.

    If `filename` is specified, saves the plot into the file,
    otherwise invokes `matplotlib.pylab.show` function
    (shows the plot). In addition, this function allows to
    specify user defined position for some subset of
    graphs nodes (with `parent_pos` parameter), nodes
    
    whose positioning is not specified in `parent_pos` are
    placed using `nx.spring_layout` function.

    Parameters
    ----------
    graph : nx.(Di)Graph
        Graph object to plot
    filename : str, optional
        Path to file to save the plot
    parent_pos : dict, optional
        Dictionary containing positioning of a subset of nodes of
        the graph, keys are node ids and values are pairs of x/y
        coordinates
    title : str, optional
        Plot title

    Returns
    -------
    pos : dict
        Dictionary containing positioning of all nodes of
        the graph, keys are node ids and values are pairs of x/y
        coordinates
    """
    """if not parent_pos:
        pos = nx.spring_layout(graph)
    else:
        pos = copy.deepcopy(parent_pos)
        random_pos = nx.spring_layout(graph)
        for node in graph.nodes():
            if node not in pos:
                pos[node] = random_pos[node]"""
    
    
    pos = fruchterman_reingold(graph)
    #可能更改drawing algrithom的地方
    nx.draw_networkx_nodes(graph, pos,
                           node_color='red',
                           node_size=20, width = 0.1,arrows=True)
    nx.draw_networkx_edges(graph, pos, width =0.5,alpha=0.4,edge_color="black")

    labels = {}
    for node in graph.nodes():
        labels[node] = str(node)

    offset = 0.1
    labels_pos = copy.deepcopy(pos)
    for p in pos:  # raise text positions
        labels_pos[p][1] += offset
    nx.draw_networkx_labels(graph, labels_pos, labels, font_size=11)

    _ticks_off()
    _set_limits(pos, labels_pos)

    if title is not None:
        plt.title(title)

    # save to a file
    if filename is not None:
        plt.savefig(filename)
        plt.clf()
    else:
        
        plt.show()
        
    return pos


def plot_instance(graph, pattern, instance, filename=None,
                  parent_pos=None, title=None):
    """Plot the graph with instance of pattern highlighted.

    This util plots a graph and highlights an instance of a pattern
    graph. If `filename` is specified, saves the plot into the file,
    otherwise invokes `matplotlib.pylab.show` function
    (shows the plot). In addition, this function allows to
    specify user defined position for some subset of
    graphs nodes (with `parent_pos` parameter), nodes
    whose positioning is not specified in `parent_pos` are
    placed using `nx.spring_layout` function.

    Parameters
    ----------
    graph : nx.(Di)Graph
        Graph object to plot
    pattern : nx.(Di)Graph
        Graph object representing a pattern graph
    instance : dict
        Dictionary representing an instance of the pattern inside
        of the graph, keys are nodes of the pattern and values are
        corresponding nodes in the graph.
    filename : str, optional
        Path to file to save the plot
    parent_pos : dict
        Dictionary containing positioning of a subset of nodes of
        the graph, keys are node ids and values are pairs of x/y
        coordinates
    title : str, optional
        Plot title

    Returns
    -------
    pos : dict
        Dictionary containing positioning of all nodes of
        the graph, keys are node ids and values are pairs of x/y
        coordinates
    """
    new_colors = ["g" if not graph.nodes()[i] in instance.values()
                  else "r" for i, c in enumerate(graph.nodes())]
    if not parent_pos:
        pos = nx.spring_layout(graph)
    else:
        pos = copy.deepcopy(parent_pos)
        random_pos = nx.spring_layout(graph)
        for node in graph.nodes():
            if node not in pos:
                pos[node] = random_pos[node]

    nx.draw_networkx_nodes(
        graph, pos, node_color=new_colors,
        node_size=100, arrows=True)
    nx.draw_networkx_edges(graph, pos, alpha=0.4)

    # Draw pattern edges highlighted
    edgelist = [(instance[edge[0]], instance[edge[1]])
                for edge in pattern.edges()]
    nx.draw_networkx_edges(
        graph, pos,
        edgelist=edgelist,
        width=3, alpha=0.5, edge_color='r')

    labels = {}
    for node in graph.nodes():
        labels[node] = node
    offset = 0.1
    labels_pos = copy.deepcopy(pos)
    for p in pos:  # raise text positions
        labels_pos[p][1] += offset
    nx.draw_networkx_labels(graph, labels_pos, labels, font_size=11)

    # color the instances

    _ticks_off()
    _set_limits(pos, labels_pos)

    if title is not None:
        plt.title(title)

    if filename is not None:
        with open(filename, "w") as f:
            plt.savefig(f)
            plt.clf()
    else:
        plt.show()
    return


def plot_rule(rule, filename=None, title=None):
    """Plot ReGraph's rule object.

    This function plots a rule object, it produces three
    separate plots: for the left-hand side of the rule,
    preserved part and the right-hand side, where the two
    homomorphsisms p->lhs, p->rhs are encoded with colors
    of nodes.

    Parameters
    ----------
    rule : regraph.rules.Rule
        Rule object to plot
    filename : str, optional
        Path to file to save the plot
    """
    fig = plt.figure(figsize=(20, 3))
    if title is not None:
        st = fig.suptitle(title, fontsize=14)

    # generate colors
    p_colors_dict = {}
    p_colors = []
    for node in rule.p.nodes():
        lhs_node = rule.p_lhs[node]
        all_p_keys = keys_by_value(rule.p_lhs, lhs_node)
        if len(all_p_keys) > 1:
            found = None
            for p_key in all_p_keys:
                if p_key != node and p_key in p_colors_dict.keys():
                    found = p_key
                    break
            if found:
                p_colors_dict[node] = p_colors_dict[found]
                p_colors.append(p_colors_dict[found])
            else:
                p_colors_dict[node] = np.random.rand(3,)
                p_colors.append(p_colors_dict[node])
        else:
            p_colors_dict[node] = np.random.rand(3,)
            p_colors.append(p_colors_dict[node])

    lhs_colors = []
    for node in rule.lhs.nodes():
        p_keys = keys_by_value(rule.p_lhs, node)
        if len(p_keys) > 0:
            lhs_colors.append(p_colors_dict[p_keys[0]])
        else:
            lhs_colors.append(np.random.rand(3,))

    rhs_colors = []
    for node in rule.rhs.nodes():
        p_keys = keys_by_value(rule.p_rhs, node)
        if len(p_keys) > 0:
            rhs_colors.append(p_colors_dict[p_keys[0]])
        else:
            rhs_colors.append(np.random.rand(3,))

    p_pos = nx.spring_layout(rule.p)
    lhs_pos = nx.spring_layout(rule.lhs)
    rhs_pos = nx.spring_layout(rule.rhs)
    for node in rule.lhs.nodes():
        p_keys = keys_by_value(rule.p_lhs, node)
        if len(p_keys) > 0:
            lhs_pos[node] = p_pos[p_keys[0]]

    for node in rule.rhs.nodes():
        p_keys = keys_by_value(rule.p_rhs, node)
        if len(p_keys) > 0:
            rhs_pos[node] = p_pos[p_keys[0]]

    plt.subplot(1, 3, 1)
    plt.title("LHS")
    _ticks_off()
    plt.xlim([-1.5, 1.5])
    plt.ylim([-1.5, 1.5])
    nx.draw_networkx_nodes(rule.lhs, lhs_pos,
                           node_color=lhs_colors,
                           node_size=100, arrows=True)
    nx.draw_networkx_edges(rule.lhs, lhs_pos, alpha=0.4)

    labels = {}
    for node in rule.lhs.nodes():
        labels[node] = str(node)
        # if types:
        #     labels[node] += ":" + str(graph.node[node].type_)
    offset = 0.2
    lhs_label_pos = copy.deepcopy(lhs_pos)
    for p in lhs_pos:  # raise text positions
        lhs_label_pos[p][1] += offset
    nx.draw_networkx_labels(rule.lhs, lhs_label_pos, labels, font_size=11)

    plt.subplot(1, 3, 2)
    plt.title("P")
    _ticks_off()
    plt.xlim([-1.5, 1.5])
    plt.ylim([-1.5, 1.5])
    nx.draw_networkx_nodes(rule.p, p_pos,
                           node_color=p_colors,
                           node_size=100, arrows=True)
    nx.draw_networkx_edges(rule.p, p_pos, alpha=0.4)

    labels = {}
    for node in rule.p.nodes():
        labels[node] = str(node)
        # if types:
        #     labels[node] += ":" + str(graph.node[node].type_)
    offset = 0.2
    p_label_pos = copy.deepcopy(p_pos)
    for p in p_pos:  # raise text positions
        p_label_pos[p][1] += offset
    nx.draw_networkx_labels(rule.p, p_label_pos, labels, font_size=11)

    plt.subplot(1, 3, 3)
    plt.title("RHS")
    _ticks_off()
    plt.xlim([-1.5, 1.5])
    plt.ylim([-1.5, 1.5])
    nx.draw_networkx_nodes(rule.rhs, rhs_pos,
                           node_color=rhs_colors,
                           node_size=100, arrows=True)
    nx.draw_networkx_edges(rule.rhs, rhs_pos, alpha=0.4)

    labels = {}
    for node in rule.rhs.nodes():
        labels[node] = str(node)
    offset = 0.2
    rhs_label_pos = copy.deepcopy(rhs_pos)
    for p in rhs_pos:  # raise text positions
        rhs_label_pos[p][1] += offset
    nx.draw_networkx_labels(rule.rhs, rhs_label_pos, labels, font_size=11)

    if title is not None:
        st.set_y(0.95)
        fig.subplots_adjust(top=0.75)

    if filename is not None:
        with open(filename, "w") as f:
            plt.savefig(f)
            plt.clf()
    else:
        plt.show()
    return

def plot_process(lhs,p,rhs, filename=None, title=None):
    
    fig = plt.figure(figsize=(20, 3))
    if title is not None:
        st = fig.suptitle(title, fontsize=14)
   
    
    p_pos = nx.spring_layout(p)
    plt.subplot(1, 3, 2)
    plt.title("P-LHS")
    _ticks_off()
    plt.xlim([-1.5, 1.5])
    plt.ylim([-1.5, 1.5])
    nx.draw_networkx_nodes(p, p_pos,
                           node_color='blue',
                           node_size=100, arrows=True)
    nx.draw_networkx_edges(p, p_pos, alpha=0.4)

    labels = {}
    for node in p.nodes():
        labels[node] = str(node)
        # if types:
        #     labels[node] += ":" + str(graph.node[node].type_)
    offset = 0.2
    p_label_pos = copy.deepcopy(p_pos)
    for p in p_pos:  # raise text positions
        p_label_pos[p][1] += offset
    nx.draw_networkx_labels(p, p_label_pos, labels, font_size=11)


    
    lhs_pos = nx.spring_layout(lhs)
    rhs_pos = nx.spring_layout(rhs)
    
    plt.subplot(1, 3, 1)
    plt.title("Source graph")
    _ticks_off()
    plt.xlim([-1.5, 1.5])
    plt.ylim([-1.5, 1.5])
    nx.draw_networkx_nodes(lhs, lhs_pos,
                           node_color='red',
                           node_size=100, arrows=True)
    nx.draw_networkx_edges(lhs, lhs_pos, alpha=0.4)

    labels = {}
    for node in lhs.nodes():
        labels[node] = str(node)
        # if types:
        #     labels[node] += ":" + str(graph.node[node].type_)
    offset = 0.2
    lhs_label_pos = copy.deepcopy(lhs_pos)
    for p in lhs_pos:  # raise text positions
        lhs_label_pos[p][1] += offset
    nx.draw_networkx_labels(lhs, lhs_label_pos, labels, font_size=11)

    
    plt.subplot(1, 3, 3)
    plt.title("P-RHS")
    _ticks_off()
    plt.xlim([-1.5, 1.5])
    plt.ylim([-1.5, 1.5])
    nx.draw_networkx_nodes(rhs, rhs_pos,
                           node_color='yellow',
                           node_size=100, arrows=True)
    nx.draw_networkx_edges(rhs, rhs_pos, alpha=0.4)

    labels = {}
    for node in rhs.nodes():
        labels[node] = str(node)
    offset = 0.2
    rhs_label_pos = copy.deepcopy(rhs_pos)
    for p in rhs_pos:  # raise text positions
        rhs_label_pos[p][1] += offset
    nx.draw_networkx_labels(rhs, rhs_label_pos, labels, font_size=11)

    if title is not None:
        st.set_y(0.95)
        fig.subplots_adjust(top=0.75)

    if filename is not None:
        with open(filename, "w") as f:
            plt.savefig(f)
            plt.clf()
    else:
        plt.show()
    return

def plot_stage(squence,filename=None):
    plt.clf()
    fig = plt.figure(figsize=(20,20))
    a = 0
    for graphs in squence:    
        graph = squence[a][0]
        plt.subplot(len(squence),1,a+1)
        plt.title(squence[a][1])
        plot_graph(graph)
        a+=1
    
    if filename is not None:
        with open(filename, "w") as f:
            plt.savefig(f)
            plt.clf()
    else:
        plt.show()
    return
   
#  fruchterman-reingold
# attractive force
def f_a(d,k):
    return d*d/k

# repulsive force
def f_r(d,k):
    return k*k/d

def fruchterman_reingold(G,iteration=1000):
    W = 1
    L = 1
    area = W*L
    k = math.sqrt(area/nx.number_of_nodes(G))

    # initial positions
    for v in nx.nodes_iter(G):
        G.node[v]['x'] = W*random()
        G.node[v]['y'] = L*random()


    t = W/10
    dt = t/(iteration+1)

    #print("area:{0}".format(area))
    #print("k:{0}".format(k))
    #print("t:{0}, dt:{1}".format(t,dt))

    for i in range(iteration):
        #print("iter {0}".format(i))

        pos = {}
        for v in G.nodes():
            pos[v] = [G.node[v]['x'],G.node[v]['y']]
        #plt.close()
        #plt.ylim([-0.1,1.1])
        #plt.xlim([-0.1,1.1])
        #plt.axis('off')
        #nx.draw_networkx(G,pos=pos,node_size=10,width=0.1,with_labels=False)
        #plt.savefig('fig{0}.png'.format(i))

        # calculate repulsive forces
        for v in G.nodes():
            G.node[v]['dx'] = 0
            G.node[v]['dy'] = 0
            for u in G.nodes():
                if v != u:
                    dx = G.node[v]['x'] - G.node[u]['x']
                    dy = G.node[v]['y'] - G.node[u]['y']
                    delta = math.sqrt(dx*dx+dy*dy)
                    if delta != 0:
                        d = f_r(delta,k)/delta
                        G.node[v]['dx'] += dx*d
                        G.node[v]['dy'] += dy*d

        # calculate attractive forces
        for v,u in G.edges():
            dx = G.node[v]['x'] - G.node[u]['x']
            dy = G.node[v]['y'] - G.node[u]['y']
            delta = math.sqrt(dx*dx+dy*dy)
            if delta != 0:
                d = f_a(delta,k)/delta
                ddx = dx*d
                ddy = dy*d
                G.node[v]['dx'] += -ddx
                G.node[u]['dx'] += +ddx
                G.node[v]['dy'] += -ddy
                G.node[u]['dy'] += +ddy

        # limit the maximum displacement to the temperature t
        # and then prevent from being displace outside frame
        for v in G.nodes():
            dx = G.node[v]['dx']
            dy = G.node[v]['dy']
            disp = math.sqrt(dx*dx+dy*dy)
            if disp != 0:
                
                d = min(disp,t)/disp
                x = G.node[v]['x'] + dx*d
                y = G.node[v]['y'] + dy*d
                x =  min(W,max(0,x)) - W/2
                y =  min(L,max(0,y)) - L/2
                G.node[v]['x'] = min(math.sqrt(W*W/4-y*y),max(-math.sqrt(W*W/4-y*y),x)) + W/2
                G.node[v]['y'] = min(math.sqrt(L*L/4-x*x),max(-math.sqrt(L*L/4-x*x),y)) + L/2

        # cooling
        t -= dt

    pos = {}
    for v in G.nodes():
        pos[v] = [G.node[v]['x'],G.node[v]['y']]
    #plt.close()
    #plt.ylim([-0.1,1.1])
    #plt.xlim([-0.1,1.1])
    #plt.axis('off')
    #nx.draw_networkx(G,pos=pos,node_size=10,width=0.1,with_labels=False)
    #plt.show()
    #plt.savefig("fig{0}.png".format(i+1))

    return pos


    
