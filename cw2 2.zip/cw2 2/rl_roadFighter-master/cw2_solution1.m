

%% ACTION CONSTANTS:
UP_LEFT = 1 ;
UP = 2 ;
UP_RIGHT = 3 ;


%% PROBLEM SPECIFICATION:

blockSize = 5 ; % This will function as the dimension of the road basis 
% images (blockSize x blockSize), as well as the view range, in rows of
% your car (including the current row).

n_MiniMapBlocksPerMap = 5 ; % determines the size of the test instance. 
% Test instances are essentially road bases stacked one on top of the
% other.

basisEpsisodeLength = blockSize - 1 ; % The agent moves forward at constant speed and
% the upper row of the map functions as a set of terminal states. So 5 rows
% -> 4 actions.

episodeLength = blockSize*n_MiniMapBlocksPerMap - 1 ;% Similarly for a complete
% scenario created from joining road basis grid maps in a line.

%discountFactor_gamma = 1 ; % if needed

rewards = [ 1, -1, -20 ] ; % the rewards are state-based. In order: paved 
% square, non-paved square, and car collision. Agents can occupy the same
% square as another car, and the collision does not end the instance, but
% there is a significant reward penalty.

probabilityOfUniformlyRandomDirectionTaken = 0.15 ; % Noisy driver actions.
% An action will not always have the desired effect. This is the
% probability that the selected action is ignored and the car uniformly 
% transitions into one of the above 3 states. If one of those states would 
% be outside the map, the next state will be the one above the current one.

roadBasisGridMaps = generateMiniMaps ; % Generates the 8 road basis grid 
% maps, complete with an initial location for your agent. (Also see the 
% GridMap class).

noCarOnRowProbability = 0.8 ; % the probability that there is no car 
% spawned for each row

seed = 1234;
rng(seed); % setting the seed for the random nunber generator

% Call this whenever starting a new episode:
MDP = generateMap( roadBasisGridMaps, n_MiniMapBlocksPerMap, blockSize, ...
    noCarOnRowProbability, probabilityOfUniformlyRandomDirectionTaken, ...
    rewards );


%% Initialising the state observation (state features) and setting up the 
% exercise approximate Q-function:
stateFeatures = ones( 4, 5 );
action_values = zeros(1, 3);

Q_test1 = ones(4, 5, 3);
Q_test1(:,:,1) = 100;
Q_test1(:,:,3) = 100;% obviously this is not a correctly computed Q-function; it does imply a policy however: Always go Up! (though on a clear road it will default to the first indexed action: go left)


%% TEST ACTION TAKING, MOVING WINDOW AND TRAJECTORY PRINTING:
% Simulating agent behaviour when following the policy defined by 
% $pi_test1$.
%
% Commented lines also have examples of use for $GridMap$'s $getReward$ and
% $getTransitions$ functions, which act as our reward and transition
% functions respectively.

weight = zeros(4, 5,3) %define the Q(s,a)
finish = 0  
learningRate=0.001 %initialise the learning rate
patience =0
previousWeights = zeros(4,5,3) %record the Q(s,a) of last time 
mode = 1  % 0��MC  1��TD

if mode == 0 %MC
    for episode = 1:100000
        currentTimeStep = 0;
        MDP = generateMap( roadBasisGridMaps, n_MiniMapBlocksPerMap, ...
            blockSize, noCarOnRowProbability, ...
            probabilityOfUniformlyRandomDirectionTaken, rewards );
        currentMap = MDP ;
        agentLocation = currentMap.Start ;
        startingLocation = agentLocation ; % Keeping record of initial location.

        % If you need to keep track of agent movement history:
        agentMovementHistory = zeros(episodeLength+1, 2) ;
        agentMovementHistory(currentTimeStep + 1, :) = agentLocation ;
        realAgentLocation = agentLocation ; % The location on the full test map.

        areturn = zeros(24,3) %to record each step's reward
        features = [] %to record each state number
        actions = zeros(24) %to record each action

        Return = 0  

        for i = 1:episodeLength
            stateFeatures = MDP.getStateFeatures(realAgentLocation) % dimensions are 4rows x 5columns
            state = MDP.getStateNumberFromCoordinates([realAgentLocation(1),realAgentLocation(2)]) %get the state number

            for action = 1:3
                action_values(action) = ...
                        sum ( sum( Q_test1(:,:,action) .* stateFeatures ) );
            end % for each possible action

            [~, actionTaken] = max(action_values)

            % give action 1 and action 3 the same chances
            if actionTaken == 1 
                if rand()> 0.5
                    actionTaken =3
                end
            end

            features(i)=state 
            actions(i)= actionTaken 

            [ agentRewardSignal, realAgentLocation, currentTimeStep, ...
                agentMovementHistory ] = ...
                actionMoveAgent( actionTaken, realAgentLocation, MDP, ...
                currentTimeStep, agentMovementHistory, ...
                probabilityOfUniformlyRandomDirectionTaken ) ;

            %save the rewardof the current state
            areturn(i,actionTaken) = agentRewardSignal 

            Return = Return + agentRewardSignal
            [ viewableGridMap, agentLocation] = setCurrentViewableGridMap( ...
                MDP, realAgentLocation, blockSize );
            currentMap = viewableGridMap ;
        end

        currentMap = MDP ;
        agentLocation = realAgentLocation ;
        Return

        %sum of the weighting rewards until the end of the episode

        finalReturns = zeros(24,3)
        for i = 1:episodeLength-1
            finalReturns(i,actions(i)) = areturn(i,actions(i))
            %weighting the rewards according to how many steps ahead of the occurence they are).
            for j = i+1:episodeLength-1
                finalReturns(i,actions(i))= finalReturns(i,actions(i))+0.1*(episodeLength-j)*areturn(j,actions(j))
            end
        end

        %update the weights using gradient descent 
        for i = 1:episodeLength-1
            feature = MDP.getStateFeatures(features(i)) 
            weight(:,:,actions(i))= updateWeights(feature,finalReturns(i,actions(i)),learningRate,weight(:,:,actions(i)))
            learningRate = 0.9999*learningRate %decrease the learning rate according to the number of episode 
        end

        %adjust the learning rate automatically
        %{
        if episode>2
            if diff(episode)> diff(episode-1)
                patience = patience +1
                if patience > 5
                    learningRate = learningRate *0.1
                    patience = 0
                end
            else 
                patience = 0
            end
        end
        %}

        % check the convergence based on the difference between the current
        % weights and last time's weights
        if(all(all(all(abs(previousWeights-weight)<0.0001))))
            break;
        else
            previousWeights = weight
        end
    end
else 
    for episode = 1:100000
        currentTimeStep = 0 ;
        MDP = generateMap( roadBasisGridMaps, n_MiniMapBlocksPerMap, ...
            blockSize, noCarOnRowProbability, ...
            probabilityOfUniformlyRandomDirectionTaken, rewards );
        currentMap = MDP ;
        agentLocation = currentMap.Start ;
        startingLocation = agentLocation ; % Keeping record of initial location.

        % If you need to keep track of agent movement history:
        agentMovementHistory = zeros(episodeLength+1, 2) ;
        agentMovementHistory(currentTimeStep + 1, :) = agentLocation ;
        realAgentLocation = agentLocation ; % The location on the full test map.
        Return = 0  
        for i = 1:episodeLength
            stateFeatures = MDP.getStateFeatures(realAgentLocation) % dimensions are 4rows x 5columns
            state = MDP.getStateNumberFromCoordinates([realAgentLocation(1),realAgentLocation(2)])
            for action = 1:3
                    action_values(action) = ...
                        sum ( sum( Q_test1(:,:,action) .* stateFeatures ) );
            end % for each possible action
            [~, actionTaken] = max(action_values)

            %If Q(s,a1)=Q(s,a3), choose a1 or a3 randomly
            if actionTaken == 1
                if rand()> 0.5
                    actionTaken =3
                end
            end
            [ agentRewardSignal, realAgentLocation, currentTimeStep, ...
                agentMovementHistory ] = ...
                actionMoveAgent( actionTaken, realAgentLocation, MDP, ...
                currentTimeStep, agentMovementHistory, ...
                probabilityOfUniformlyRandomDirectionTaken ) ;


            Return = Return + agentRewardSignal
            %get the features of the next state
            newFeatures = MDP.getStateFeatures(realAgentLocation)
            index = (episode-1)*25 + i
            % r+ gamma*V(s')
            goal = agentRewardSignal+ 1*sum (sum(weight(:,:,actionTaken) .* newFeatures ) )
            %update the weights using gradient descent 
            weight(:,:,actionTaken) = updateWeights(stateFeatures,goal,learningRate,weight(:,:,actionTaken))
            learningRate = learningRate* 0.9999

            [ viewableGridMap, agentLocation ] = setCurrentViewableGridMap( ...
                MDP, realAgentLocation, blockSize );
            currentMap = viewableGridMap ;

        end

        currentMap = MDP ;
        agentLocation = realAgentLocation ;
        Return
        
        % check the convergence based on the difference between the current
        % weights and last time's weights
        if(all(all(all(abs(previousWeights-weight)<0.0001))))
            finish = 1
            break;
        else
            previousWeights = weight
        end
        if finish ==1
            break;
        end
    end
end
         
%%gradient descent
function[W]=updateWeights(X,Y,alpha,W) %alpha is the learning rate
    X = reshape(X,1,[])
    W = reshape(W,1,[])  
    %k = 0;%iteration times  
    detaW = zeros(20,1);  
    error = Y- X*W' 
    detaW = detaW + alpha *X'*error; 
    W = W + detaW';
    W = reshape(W,4,5)
    %k = k+1;  
    %{
        while true  
            detaW = zeros(20,1);  
            error = Y- X*W' 
            detaW = detaW + alpha *X'*error; 
            W = W + detaW';
            k = k+1;  
            
            if 1/2*( norm(Y - X*W') )^2 < 1 || k>10000 % if the error< 5 or iteraion time >10000,then stop the iteration  
                break;  
            end  
            fprintf('iterator times %d, error %f\n',k,1/2*( norm(Y - X*W') )^2); 
        end
    %}
end


